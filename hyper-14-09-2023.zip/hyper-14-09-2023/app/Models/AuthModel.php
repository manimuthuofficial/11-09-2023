<?php

namespace App\Models;

use CodeIgniter\Model;

class AuthModel extends Model
{
    protected $table = 'users'; // Replace 'users' with your actual table name.
    protected $primaryKey = 'id'; // Replace 'id' with your actual primary key field name.
    protected $allowedFields = ['name', 'email', 'password', 'profile_img_ext'];
}

?>

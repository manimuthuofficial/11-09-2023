<?php

namespace App\Controllers;

use App\Models\AuthModel;

class AuthController extends BaseController
{
    public function signIn()
    {
        return view('auth/signin/index');
    }
    public function signUp()
    {
        return view('auth/signup/index');
    }
    public function authInsert()
    {
                       
        $AuthModel = new AuthModel();

        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'password' => $this->request->getPost('password'),
            //'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
        ];

        
        /*  START Check if the email already exists in the database. */
        // Check if the email already exists in the database.
        if ($this->emailExists($data['email'])) 
        {
            return json_encode(['status' => 'email_exists']);
        }
        /*  END Check if the email already exists in the database. */

        /*  START insert function. */
        if ($AuthModel->insert($data)) 
        {
            return json_encode(['status' => 'success']);
        } 
        else 
        {
            return json_encode(['status' => 'error']);
        }
         /*  END insert function. */
    }


    /*  START Email exists check function */
    // Function to check if the email exists in the database.
    private function emailExists($email)
    {
        $AuthModel = new AuthModel();
        $existingUser = $AuthModel->where('email', $email)->first();
        return ($existingUser !== null);
    }
    /*  END Email exists check function */




    
}

?>
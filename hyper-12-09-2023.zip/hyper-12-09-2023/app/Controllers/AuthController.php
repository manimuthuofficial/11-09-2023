<?php

namespace App\Controllers;

use App\Models\AuthModel;

class AuthController extends BaseController
{
    public function signIn()
    {
        return view('auth/signin/index');
    }
    public function signUp()
    {
        return view('auth/signup/index');
    }
    public function authInsert()
    {
        
        $AuthModel = new AuthModel();

        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
        ];

        if ($AuthModel->insert($data)) 
        {
            return json_encode(['status' => 'success']);
        } 
        else 
        {
            return json_encode(['status' => 'error']);
        }
    }

    
}

?>
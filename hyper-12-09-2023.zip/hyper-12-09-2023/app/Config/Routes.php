<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

//$routes->get('/', 'Home::index');

$routes->get('/', 'AuthController::signIn');
$routes->get('/signup', 'AuthController::signUp');
$routes->post('/authInsert', 'AuthController::authInsert');


?>


<?php

namespace App\Controllers;

use App\Models\UserModel;

class AuthController extends BaseController
{
    public function signIn()
    {
        return view('auth/signin/index');
    }
    public function signUp()
    {
        return view('auth/signup/index');
    }

    
}

?>